package com.cap.dao;

public class PasswordNotFoundException extends RuntimeException {
	public PasswordNotFoundException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}
}
