package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CoachingBeanPage {
	WebDriver driver;
	
	@FindBy(how=How.NAME,using="fname")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(how=How.NAME,using="lname")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(how=How.NAME,using="email")
	@CacheLookup
	WebElement email;
	
	
	@FindBy(how=How.NAME,using="mobile")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[6]/td[2]/select")
	@CacheLookup
	WebElement typeOfTuition;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	WebElement city;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	WebElement modeOfLearning;
	
	@FindBy(how=How.NAME,using="enqdetails")
	@CacheLookup
	WebElement yourEnquiry;
	
	@FindBy(how=How.ID, using="Submit1")
	@CacheLookup
	WebElement submitRequest;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getTypeOfTuition() {
		return typeOfTuition;
	}

	public void setTypeOfTuition(String typeOfTuition) {
		this.typeOfTuition.sendKeys(typeOfTuition);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getModeOfLearning() {
		return modeOfLearning;
	}

	public void setModeOfLearning(String modeOfLearning) {
		this.modeOfLearning.sendKeys(modeOfLearning);
	}

	public WebElement getYourEnquiry() {
		return yourEnquiry;
	}

	public void setYourEnquiry(String yourEnquiry) {
		this.yourEnquiry.sendKeys(yourEnquiry);
	}

	public WebElement getSubmitRequest() {
		return submitRequest;
	}

	public void setSubmitRequest() {
		this.submitRequest.click();
	}

	public CoachingBeanPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	
	

}
