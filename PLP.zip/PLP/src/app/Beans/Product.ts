import { Merchant } from './Merchant';
import { Category } from './Category';

export class Product{
    productId:number;
    productName:String;
    productDescription:String;
    productQuantity:number;
    productPrice:number;
    productDiscount:number;
    merchant:Merchant;
    category:Category;

    constructor(productId:number,
        productName:String,
        productDescription:String,
        productQuantity:number,
        productPrice:number,
        productDiscount:number,
        merchant:Merchant,
        category:Category){
            this.productName=productName
            this.category=category
            this.merchant=merchant;
            this.productDescription=productDescription
            this.productDiscount=productDiscount
            this.productQuantity=productQuantity
            this.productPrice=productPrice
            this.productId=productId
        }
}