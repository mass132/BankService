package com.cap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelprojectApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(ParallelprojectApplication.class, args);
		System.out.println("port number is 1422");
		
	}

}
