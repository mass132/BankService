package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Stock;

public interface IInvoiceService {

	Invoice generateInvoice(long customerId, double adminDiscount, double finalAmount);



	DeliveryStatus generateOrder(Order order, long productId, long invoiceId);



	Coupon viewByCouponCode(String couponCode);



	double viewByProductId(long productId);



	boolean findProductQuantity(long productId, int quantity);



	List<List<Order>> getOrders(long customerId);



	Invoice getInvoice(long invoiceId);



	List<Order> getOrder(long invoiceId);



	double getPrice(long productId);



	List<Cart> getCart(long customerId);







	Cart generateCart(long customerId, long productId);



	Stock updateInventory(Long productId, Integer quantity);



	
}
