package com.cap.CapStore.service;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
import com.cap.CapStore.dao.ICouponDao;
import com.cap.CapStore.entities.Coupons;
	@Service("couponService")
	public class CouponService implements ICouponService{

		@Autowired
		private ICouponDao couponsDao;
		
		@Override
		public Coupons checkIfCouponCodeIsValid(String couponCode) {
			
			Coupons myCoupon=couponsDao.findByCouponCode(couponCode);
			if(myCoupon.equals(null)) {
				return null;
			}
			return myCoupon;
		}

		@Override
		public boolean generateCoupon(Coupons coupon) {
			
			couponsDao.save(coupon);

			return true;
		}
	}

