import { Component, OnInit } from '@angular/core';
import { GenerateInvoiceServiceService } from '../generate-invoice-service.service';
import { Router } from '@angular/router';
import { AccountDetail } from '../Beans/AccountDetail';
@Component({
  selector: 'app-carddetails',
  templateUrl: './carddetails.component.html',
  styleUrls: ['./carddetails.component.css']
})
export class CarddetailsComponent implements OnInit {
  generateInvoiceService: GenerateInvoiceServiceService;
  router: Router;
  accountDetails:AccountDetail;
  account;
  constructor(generateInvoice: GenerateInvoiceServiceService, router: Router) {
    this.generateInvoiceService = generateInvoice;
    this.router = router;
  }

  ngOnInit() {
  }
makePayment(data:any){
  if(data.cardNo=="" || data.cvv==""){
    alert("Please fill all information")
    return;
  }
  
  console.log(this.generateInvoiceService.invoiceId)
 let data1=this.generateInvoiceService.fetchAccount(10000);
 data1.subscribe(data2 => {
      this.account= data2;
      console.log(this.account)
      if(this.account.cvv!=data.cvv || this.account.cardNo!=data.cardNo){
        alert(" Invalid card Number or Wrong CVV ")
        return;
      }
      let data3 = this.generateInvoiceService.updateCard(this.account.cardNo,this.generateInvoiceService.finalAmount);
      data3.subscribe(data4 => {
        let account1 = data4;
        console.log(account1)
      })
      this.router.navigate(["app-invoice-bill"])
     
      
 })

  // console.log(d)
  // // this.accountDetails=new AccountDetail(data.cardNo,data.cardName,data.cvv,1000,data.month,data.year);
  // // console.log(this.accountDetails)
  // // let data1 = this.generateInvoiceService.addCard(this.accountDetails,10000);
  //   data1.subscribe(data2 => {
  //     this.account = data2;
  //     console.log(data2)
  //     console.log(this.account);
  //   })
}
}
