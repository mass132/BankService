package com.capgemini.capstore.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Revenue;
import com.capgemini.capstore.dao.IInvoiceDao;
import com.capgemini.capstore.dao.IRevenueDao;

@Service
public class RevenueImpl implements IRevenueService {

	@Autowired
	IRevenueDao revenueDao;
	
	
	@Autowired
	IInvoiceDao invoiceDao;
	
	@Override
	public Revenue getDetails(long invoiceId) {
		Optional<Invoice> optional = invoiceDao.findById(invoiceId);
		Invoice invoice = optional.get();
		double amount = invoice.getFinalAmount();
		Optional<Revenue> optional1=revenueDao.findById((long) (1000001));
		Revenue rev2=optional1.get();
		rev2.setPreviousRevenue(rev2.getCurrentRevenue());
		System.out.println("The amount to be paid is"+amount);
	 rev2.setCurrentRevenue(rev2.getCurrentRevenue()+amount);
		
		Revenue revenue=revenueDao.save(rev2);
		return rev2;

}

}


	