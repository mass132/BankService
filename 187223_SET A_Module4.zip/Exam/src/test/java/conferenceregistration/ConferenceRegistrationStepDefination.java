package conferenceregistration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagebean.ConferenceRegistrationPageFactory;

public class ConferenceRegistrationStepDefination {
	
	private WebDriver driver;
	ConferenceRegistrationPageFactory conferenceregistrationpagefactory;
	 String actualTitle;
	 String expectedTitle;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\akeshire\\Desktop\\testing\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	
	@Given("^user is on 'ConferenceRegistration' page$")
	public void user_is_on_ConferenceRegistration_page() throws Throwable {
	  driver.get("D:\\Users\\akeshire\\Desktop\\testing\\ConferenceRegistartion.html");
	  conferenceregistrationpagefactory = new ConferenceRegistrationPageFactory(driver);
	}

	@When("^User finds the Title bar$")
	public void user_finds_the_Title_bar() throws Throwable {
		 actualTitle = driver.getTitle();
	    
	}

	@Then("^He checks that it is same to 'Conference Registration' or not$")
	public void he_checks_that_it_is_same_to_Conference_Registration_or_not() throws Throwable {
		 expectedTitle ="Conference Registration";
    	 Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("");
		conferenceregistrationpagefactory.setNextlink();
	   
	}

	@Then("^displays 'Please fill the First Name'$")
	public void displays_Please_fill_the_First_Name() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
	    
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("");
		conferenceregistrationpagefactory.setNextlink();
		
	  
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	 
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("");
		conferenceregistrationpagefactory.setNextlink();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("");
		conferenceregistrationpagefactory.setNextlink();
	    
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No() throws Throwable {
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("52896");
		conferenceregistrationpagefactory.setNextlink();
	    
	}

	@Then("^display 'Please enter valid Contact Number'$")
	public void display_Please_enter_valid_Contact_Number() throws Throwable {
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid Number of People attending$")
	public void user_enters_invalid_Number_of_People_attending() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setNextlink();
	   
	}

	@Then("^display 'Number of people attending'$")
	public void display_Number_of_people_attending() throws Throwable {
		String expectedMessage="Please fill the Number of people attending";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user does not enter buildingname and room no$")
	public void user_does_not_enter_buildingname_and_room_no() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setBuildingnameandroomno("");
		conferenceregistrationpagefactory.setNextlink();
	   
	}

	@Then("^display 'Please Fill the building and room no'$")
	public void display_Please_Fill_the_building_and_room_no() throws Throwable {
		String expectedMessage="Please fill the Building & Room No";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	  
	}

	@When("^user does not enter areaname$")
	public void user_does_not_enter_areaname() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setBuildingnameandroomno("mahendra and 481");
		conferenceregistrationpagefactory.setAreaname("");
		conferenceregistrationpagefactory.setNextlink();
	   
	}

	@Then("^display 'Please fill the area name'$")
	public void display_Please_fill_the_area_name() throws Throwable {
		String expectedMessage="Please fill the Area name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	  
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setBuildingnameandroomno("mahendra and 481");
		conferenceregistrationpagefactory.setAreaname("chengalpattu");
		conferenceregistrationpagefactory.setCityselection("");
		conferenceregistrationpagefactory.setNextlink();
	   
	}

	@Then("^display 'Please select City'$")
	public void display_Please_select_City() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setBuildingnameandroomno("mahendra and 481");
		conferenceregistrationpagefactory.setAreaname("chengalpattu");
		conferenceregistrationpagefactory.setCityselection("Chennai");
		conferenceregistrationpagefactory.setStateselection("");
		conferenceregistrationpagefactory.setNextlink();
	}

	@Then("^display 'Please select  State'$")
	public void display_Please_select_State() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid conferencedetails$")
	public void user_enters_invalid_conferencedetails() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setBuildingnameandroomno("mahendra and 481");
		conferenceregistrationpagefactory.setAreaname("chengalpattu");
		conferenceregistrationpagefactory.setCityselection("Chennai");
		conferenceregistrationpagefactory.setStateselection("Tamilnadu");
		conferenceregistrationpagefactory.setConferencefullaccess(null);
		conferenceregistrationpagefactory.setNextlink();
	  
	}

	@Then("^display 'conference details are validated'$")
	public void display_conference_details_are_validated() throws Throwable {
		String expectedMessage="Please Select MemeberShip status";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		conferenceregistrationpagefactory.setFirstname("capgemini");
		conferenceregistrationpagefactory.setLastname("chennai");
		conferenceregistrationpagefactory.setEmailid("capgemini.chennai@gmail.com");
		conferenceregistrationpagefactory.setContactnumber("7093117585");
		conferenceregistrationpagefactory.setPeopleCount(2);
		conferenceregistrationpagefactory.setBuildingnameandroomno("mahendra and 481");
		conferenceregistrationpagefactory.setAreaname("chengalpattu");
		conferenceregistrationpagefactory.setCityselection("Chennai");
		conferenceregistrationpagefactory.setStateselection("Tamilnadu");
		conferenceregistrationpagefactory.setConferencefullaccess(true);
		conferenceregistrationpagefactory.setNextlink();
	   
	}

	@Then("^display 'PaymentDetails' Page$")
	public void display_PaymentDetails_Page() throws Throwable {
		driver.get("D:\\Users\\akeshire\\Desktop\\testing\\PaymentDetails.html");
	    
	}

	
	
	
	
	
	
	
	
	
	
	
	

}
