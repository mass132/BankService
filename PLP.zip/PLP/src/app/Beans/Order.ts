import { Invoice } from './Invoice';
import { Product } from './Product';

export class Order{
    orderId:number;
    discountTotal:number;
    quantity:number;
    totalAmount:number;
    invoice:Invoice;
    products:Product;
    
    constructor( orderId:number,
        discountTotal:number,
        quantity:number,
        totalAmount:number,
        invoice:Invoice,
        products:Product){
            this.discountTotal=discountTotal;
            this.invoice=invoice;
            this.orderId=orderId;
            this.products=products;
            this.quantity=quantity;
            this.totalAmount=totalAmount;
        }
}