package paymentdetails;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagebean.PaymentDetailsPageFactory;

public class PaymentDetailsStepDefination {
	
	WebDriver driver;
	PaymentDetailsPageFactory paymentdetailspagefactory;
	String actualTitle;
	 String expectedTitle;
	 
	 
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\akeshire\\Desktop\\testing\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'paymentdetails' page$")
	public void user_is_on_paymentdetails_page() throws Throwable {
		driver.get("D:\\Users\\akeshire\\Desktop\\testing\\PaymentDetails.html");
		paymentdetailspagefactory =new PaymentDetailsPageFactory(driver);
	}
	@When("^User finds the Title bar$")
	public void user_finds_the_Title_bar() throws Throwable {
		actualTitle = driver.getTitle();
	}

	@Then("^He checks that it is same to 'paymentdetails' or not$")
	public void he_checks_that_it_is_same_to_paymentdetails_or_not() throws Throwable {
		 expectedTitle ="Payment Details";
    	 Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^user enters invalid cardholdername$")
	public void user_enters_invalid_cardholdername() throws Throwable {
		paymentdetailspagefactory.setCardholdername("");
		paymentdetailspagefactory.setPaymentbutton();
	  
	}

	@Then("^displays 'Please fill the cardholdername'$")
	public void displays_Please_fill_the_cardholdername() throws Throwable {
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid debitcardnumber$")
	public void user_enters_invalid_debitcardnumber() throws Throwable {
		paymentdetailspagefactory.setCardholdername("capgemini");
		paymentdetailspagefactory.setDebitcardnumber("");
		paymentdetailspagefactory.setPaymentbutton();
	   
	}

	@Then("^displays 'Please fill the debitcardnumber'$")
	public void displays_Please_fill_the_debitcardnumber() throws Throwable {
		String expectedMessage="Please fill the Debit card Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	
	}

	@When("^user enters invalid expirymonth$")
	public void user_enters_invalid_expirymonth() throws Throwable {
		paymentdetailspagefactory.setCardholdername("capgemini");
		paymentdetailspagefactory.setDebitcardnumber("123456");
		paymentdetailspagefactory.setCvv("234");
		paymentdetailspagefactory.setExpirymonth("");
		paymentdetailspagefactory.setPaymentbutton();
	   
	}

	@Then("^displays 'Please fill the expirymonth'$")
	public void displays_Please_fill_the_expirymonth() throws Throwable {
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}

	@When("^user enters invalid  expiryyear$")
	public void user_enters_invalid_expiryyear() throws Throwable {
		paymentdetailspagefactory.setCardholdername("capgemini");
		paymentdetailspagefactory.setDebitcardnumber("123456");
		paymentdetailspagefactory.setCvv("234");
		paymentdetailspagefactory.setExpirymonth("june");
		paymentdetailspagefactory.setExpiryyear("");
		paymentdetailspagefactory.setPaymentbutton();
	   
	}

	@Then("^displays 'Please fill the  expiryyear'$")
	public void displays_Please_fill_the_expiryyear() throws Throwable {
		
		String expectedMessage="Please fill the expiration year";
	String actualMessage=driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
	   
	}

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
		paymentdetailspagefactory.setCardholdername("capgemini");
		paymentdetailspagefactory.setDebitcardnumber("123456");
		paymentdetailspagefactory.setCvv("234");
		paymentdetailspagefactory.setExpirymonth("june");
		paymentdetailspagefactory.setExpiryyear("2021");
		paymentdetailspagefactory.setPaymentbutton();
	   
	}

	@Then("^displays 'Conference room booking successfully done!!!'$")
	public void displays_Conference_room_booking_successfully_done() throws Throwable {
		
		
	}
	
}
