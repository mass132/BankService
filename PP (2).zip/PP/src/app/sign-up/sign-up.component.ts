import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { Customer } from 'src/Models/Customer';
import { Transactions } from 'src/Models/Transactions';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  createdAccount:Customer;
  service: ServiceService;
  createdTransaction:Transactions;
  createdFlag:boolean=false;
  Router: Router;
 
  constructor(service:ServiceService,Router: Router) 
  {
    this.service=service;
    this.Router=Router;
  }

  
  add(data:any){
   var account;
    var name = data.cname;
    var phone = data.cphone;
    var password = data.cpassword;
    var city = data.ccity;
    // data.caccount=data.cphone;
    // data.cbalance=5000;
   // this.createdAccount=new Customer(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    account=this.service.add(name,phone,password,city);
    // this.createdTransaction=new Transactions("125",data.caccount,"",data.cbalance,"Account Creation");
    // this.service.addTransactions(this.createdTransaction)
    alert("Added Succesfully!!!\nYour Account No. is : "+account);
    this.createdFlag=true;
    this.Router.navigate(['/login']);
   
  }

  ngOnInit() {
  }

}
