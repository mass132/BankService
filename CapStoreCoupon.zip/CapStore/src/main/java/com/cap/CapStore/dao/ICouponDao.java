package com.cap.CapStore.dao;

	import javax.transaction.Transactional;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.data.jpa.repository.Query;
	import org.springframework.stereotype.Repository;

import com.cap.CapStore.entities.Coupons;

	@Repository("couponsDao")
	@Transactional
	public interface ICouponDao extends JpaRepository<Coupons,Integer>{
		
		@Query("from Coupons where couponCode=:couponCode")
		public Coupons findByCouponCode(String couponCode);
	}
