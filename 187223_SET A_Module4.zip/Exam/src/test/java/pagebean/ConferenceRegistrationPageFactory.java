package pagebean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ConferenceRegistrationPageFactory {
WebDriver driver;

//initiating Elements
	public ConferenceRegistrationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


@FindBy(how=How.ID, using="txtFirstName")
@CacheLookup
WebElement firstname;

@FindBy(how=How.ID, using="txtLastName")
@CacheLookup
WebElement lastname;

@FindBy(how=How.ID, using="txtEmail")
@CacheLookup
WebElement emailid;

@FindBy(css="input[pattern='[789][0-9]{9}']")
@CacheLookup
WebElement contactnumber;


@FindBy(how=How.NAME, using="size")
@CacheLookup
int peopleCount;

@FindBy(how=How.ID, using="txtAddress1")
@CacheLookup
WebElement buildingnameandroomno;

@FindBy(how=How.ID, using="txtAddress2")
@CacheLookup
WebElement areaname;

@FindBy(how=How.NAME, using="city")
@CacheLookup
WebElement cityselection;

@FindBy(how=How.NAME, using="state")
@CacheLookup
WebElement stateselection;


@FindBy(how=How.NAME, using="memberStatus")
@CacheLookup
boolean conferencefullaccess;

@FindBy(how=How.XPATH, using="/html/body/form/table/tbody/tr[14]/td/a")
@CacheLookup
WebElement nextlink;


public WebElement getFirstname() {
	return firstname;
}

public void setFirstname(String firstname) {
	this.firstname.sendKeys(firstname);
}

public WebElement getLastname() {
	return lastname;
}

public void setLastname(String lastname) {
	this.lastname.sendKeys(lastname);
}

public WebElement getEmailid() {
	return emailid;
}

public void setEmailid(String emailid) {
	this.emailid.sendKeys(emailid);
}

public WebElement getContactnumber() {
	return contactnumber;
}

public void setContactnumber(String contactnumber) {
	this.contactnumber.sendKeys(contactnumber);
}


public int getPeopleCount() {
	return peopleCount;
}

public void setPeopleCount(int peopleCount) {
	this.peopleCount = peopleCount;
}

public WebElement getBuildingnameandroomno() {
	return buildingnameandroomno;
}

public void setBuildingnameandroomno(String buildingnameandroomno) {
	this.buildingnameandroomno.sendKeys(buildingnameandroomno);
}

public WebElement getAreaname() {
	return areaname;
}

public void setAreaname(String areaname) {
	this.areaname.sendKeys(areaname);
}

public WebElement getCityselection() {
	return cityselection;
}

public void setCityselection(String cityselection) {
	this.cityselection.sendKeys(cityselection);
}

public WebElement getStateselection() {
	return stateselection;
}

public void setStateselection(String stateselection) {
	this.stateselection.sendKeys(stateselection);
}

public boolean getConferencefullaccess() {
	return conferencefullaccess;
}

public void setConferencefullaccess(Boolean conferencefullaccess) {
	this.conferencefullaccess=conferencefullaccess;
}

public WebElement getNextlink() {
	return nextlink;
}

public void setNextlink() {
	this.nextlink.click();
}


}
