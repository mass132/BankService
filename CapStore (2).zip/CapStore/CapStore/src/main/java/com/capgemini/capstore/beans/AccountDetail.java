package com.capgemini.capstore.beans;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_account_details")
public class AccountDetail {
	@Id
	private long cardNo;
	private String cardholderName;
	private String cvv;
	private double balance;
	private String month;
	private String year;
	@OneToOne
	private Customer customer;
	public AccountDetail(long cardNo, String cardholderName, String cvv, double balance, String month, String year,
			Customer customer) {
		super();
		this.cardNo = cardNo;
		this.cardholderName = cardholderName;
		this.cvv = cvv;
		this.balance = balance;
		this.month = month;
		this.year = year;
		this.customer = customer;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	
	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	
	public long getCardNo() {
		return cardNo;
	}

	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}

	public String getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	
	public AccountDetail() {
		super();
	}

	


	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}