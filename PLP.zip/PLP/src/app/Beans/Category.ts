export class Category{
    categoryId:number;
    categoryGender:String;
    categoryType:String;

    constructor( categoryId:number,
        categoryGender:String,
        categoryType:String){
            this.categoryGender=categoryGender;
            this.categoryId=categoryId;
            this.categoryType=categoryType;
        }
}