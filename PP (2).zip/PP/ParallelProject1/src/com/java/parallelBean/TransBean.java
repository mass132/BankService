package com.java.parallelBean;
public class TransBean {
private long transid;
private long Accountnumber;
private long Amount;
private long Amountrecieved;
private String Transtype;
private String Transdate;
public TransBean()
{
	super();
	this.transid=transid;
	this.Accountnumber=Accountnumber;
	this.Amount=Amount;
	this.Amountrecieved=Amountrecieved;
	this.Transtype=Transtype;
	this.Transdate=Transdate;
}
@Override
public String toString() {
	return "TransBean [transid=" + transid + ", Accountnumber=" + Accountnumber + ", Amount=" + Amount
			+ ", Amountrecieved=" + Amountrecieved + ", Transtype=" + Transtype + ", Transdate=" + Transdate + "//n]";
}
public long getTransid() {
	return transid;
}
public void setTransid(long transid) {
	this.transid = transid;
}
public long getAccountnumber() {
	return Accountnumber;
}
public void setAccountnumber(long accountnumber) {
	Accountnumber = accountnumber;
}
public long getAmount() {
	return Amount;
}
public void setAmount(long amount) {
	Amount = amount;
}
public long getAmountrecieved() {
	return Amountrecieved;
}
public void setAmountrecieved(long amountrecieved) {
	Amountrecieved = amountrecieved;
}
public String getTranstype() {
	return Transtype;
}
public void setTranstype(String transtype) {
	Transtype = transtype;
}
public String getTransdate() {
	return Transdate;
}
public void setTransdate(String transdate) {
	Transdate = transdate;
}

}
