package paymentdetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},glue="paymentdetails",dryRun=false,features="D://Users//akeshire//Desktop//testing//Exam//src//test//resources//PaymentDetails")
public class TestRunner {

}
