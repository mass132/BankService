package com.capgemini.capstore.beans;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_revenue")
public class Revenue {
	@Id
	private long revenueId;
	@Column(length = 20)
	private double previousRevenue;
	@Column(length = 20)
	private double currentRevenue;


	public Revenue(long revenueId,  double previousRevenue, double currentRevenue) {
		super();
		this.revenueId = revenueId;
		
		this.previousRevenue = previousRevenue;
		this.currentRevenue = currentRevenue;
		
	}

	public Revenue() {
		super();
	}

	public long getRevenueId() {
		return revenueId;
	}

	public void setRevenueId(long revenueId) {
		this.revenueId = revenueId;
	}

	public double getPreviousRevenue() {
		return previousRevenue;
	}

	public void setPreviousRevenue(double previousRevenue) {
		this.previousRevenue = previousRevenue;
	}

	public double getCurrentRevenue() {
		return currentRevenue;
	}

	public void setCurrentRevenue(double currentRevenue) {
		this.currentRevenue = currentRevenue;
	}

	


}