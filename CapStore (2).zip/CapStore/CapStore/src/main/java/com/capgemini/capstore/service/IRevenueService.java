package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Revenue;

public interface IRevenueService {

	public Revenue getDetails(long invoiceId);

	

}
