package com.cap.CapStore.service;

import com.cap.CapStore.entities.Coupons;

public interface ICouponService {
	public Coupons checkIfCouponCodeIsValid(String couponCode);
	public boolean generateCoupon(Coupons coupon);
}
