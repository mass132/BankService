package com.capgemini.capstore.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Product;
@CrossOrigin(origins = "http://localhost:4200")
public interface IProductDao extends JpaRepository<Product, Long>{
	
	@Query("from Product where productId=?1")
	Product findByProductId(long productId);
	
	 @Query("select o from Order o where o.quantity=?1")
	    Optional<Product> findByQuantity(int quantity);
}
