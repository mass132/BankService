package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.capgemini.capstore.beans.AccountDetail;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Order;

@CrossOrigin(origins = "http://localhost:4200")
public interface TransactionDaoI extends JpaRepository<AccountDetail, Long>{
	@Query("from AccountDetail where customer=?1")
	AccountDetail findByCustomer(Customer customer);

}
