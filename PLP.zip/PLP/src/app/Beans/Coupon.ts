import { Product } from './Product';
import { Category } from './Category';

export class Coupon{
    couponId:number;
    couponCode:String;
    maxAmount:number;
    minAmount:number;
    product:Product;
    category:Category;
    discountPercent:number;
    generationDate:Date;
    expiry:Date;

}