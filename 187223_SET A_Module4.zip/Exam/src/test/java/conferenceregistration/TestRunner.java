package conferenceregistration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {
		"pretty" }, glue = "conferenceregistration", features = "D://Users//akeshire//Desktop//testing//Exam//src//test//resources//ConferenceRegistration")
public class TestRunner {

}
