package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Order;

@CrossOrigin(origins = "http://localhost:4200")
public interface IOrderDao extends JpaRepository<Order, Long> {
	@Query("from Order where invoice=?1")
	List<Order> findByOrderId(Invoice invoice1);

}
