    
package stepdefinition;


import java.util.concurrent.TimeUnit;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pom.CoachingBeanPage;



public class CoachingStepDefinition {
    
    private WebDriver driver;
    private CoachingBeanPage bean;
    
    @Before
    public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\pyarravu\\Desktop\\chromedriver\\chromedriver.exe");
        driver= new ChromeDriver();
    }
    
    @Before
    public void waitscenario() {
        driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
    }


    
    @Given("^User is on 'Tuition Enquiry Details Form' Page$")
    public void user_is_on_Tuition_Enquiry_Details_Form_Page() throws Throwable {
        driver.get("D:\\Users\\pyarravu\\Desktop\\m4\\Coaching_Class_Enquiry\\Coaching_Class_Enquiry.html");
           bean=new CoachingBeanPage(driver);
       
    }


    @Then("^'Verifying the title of page'$")
    public void verifying_the_title_of_page() throws Throwable {
        String expectedMessage="Online Coaching Class Enquiry Form";
        String actualMessage=driver.getTitle();
        Assert.assertEquals(expectedMessage, actualMessage);
        driver.close();
    }


    @Then("^'Verifying the Text on page'$")
    public void verifying_the_Text_on_page() throws Throwable {
        String bodyText = driver.findElement(By.tagName("body")).getText();
        Assert.assertTrue("Text not found!", bodyText.contains("Shree Coaching Classes Enquiry"));
        driver.close();
    }


    @When("^User enters invalid first name$")
    public void user_enters_invalid_first_name() throws Throwable {
        bean.setFirstName("");
        bean.setSubmitRequest();
    }


    @Then("^displays 'First Name must be filled out'$")
    public void displays_First_Name_must_be_filled_out() throws Throwable {
        String expectedMessage="First Name must be filled out";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        driver.close();
    }


    @When("^User enters invalid last name$")
    public void user_enters_invalid_last_name() throws Throwable {
      bean.setFirstName("pavan");
      bean.setLastName("");
      bean.setSubmitRequest();
    }


    @Then("^displays 'Last Name must be filled out'$")
    public void displays_Last_Name_must_be_filled_out() throws Throwable {
        String expectedMessage="Last Name must be filled out";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        driver.close();


        
    }


    
@When("^User enters invalid email$")
    public void user_enters_invalid_email() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yarravula");
        bean.setEmail("");
        bean.setSubmitRequest();
    }


    @Then("^displays 'Email must be filled out'$")
    public void displays_Email_must_be_filled_out() throws Throwable {
        String expectedMessage="Email must be filled out";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        driver.close();
       
    }


    @When("^User enters alphabetic Mobile Number$")
    public void user_enters_alphabetic_Mobile_Number() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("kumar");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("hdjdgtjj");
        bean.setSubmitRequest();
    }


    @Then("^displays 'Enter numeric value'$")
    public void displays_Enter_numeric_value() throws Throwable {
        String expectedMessage="Enter numeric value";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        driver.close();
       
    }


    @When("^User enters Invalid Mobile Number$")
    public void user_enters_Invalid_Mobile_Number() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yarravula");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("58466");
        bean.setSubmitRequest();
    }


    @Then("^displays 'Enter (\\d+) digit Mobile number'$")
    public void displays_Enter_digit_Mobile_number(int arg1) throws Throwable {
        String expectedMessage="Enter 10 digit Mobile number";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        driver.close();
        
    }


    @When("^User enters Invalid type of tuition$")
    public void user_enters_Invalid_type_of_tuition() throws Throwable {
        bean.setFirstName("pacvan");
        bean.setLastName("tyarravu");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("9912488866");
        bean.setTypeOfTuition("Spoken English");
        bean.setSubmitRequest();
        
    }


    @Then("^displays 'Enter valid type'$")
    public void displays_Enter_valid_type() throws Throwable {
       
    }


    @When("^User enters Invalid City Preference$")
    public void user_enters_Invalid_City_Preference() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yaravula");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("9912488866");
        bean.setTypeOfTuition("Spoken English");
        bean.setCity("Pune");
        bean.setSubmitRequest();
       
    }


    @Then("^displays 'Enter valid city'$")
    public void displays_Enter_valid_city() throws Throwable {
       
    }


    @When("^User enters Invalid Mode of learning$")
    public void user_enters_Invalid_Mode_of_learning() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yarravula");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("9912488866");
        bean.setTypeOfTuition("Spoken English");
        bean.setCity("Pune");
        bean.setModeOfLearning("Class room training");
        bean.setSubmitRequest();
      
    }


    @Then("^displays 'Enter valid mode of learning'$")
    public void displays_Enter_valid_mode_of_learning() throws Throwable {
      
    }


    @When("^User enters Invalid enquiry details$")
    public void user_enters_Invalid_enquiry_details() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yarravula");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("9912488866");
        bean.setTypeOfTuition("Spoken English");
        bean.setCity("Pune");
        bean.setModeOfLearning("Class room training");
        bean.setYourEnquiry("");
        bean.setSubmitRequest();
       
    }


    @Then("^displays 'Enter valid enquiry details'$")
    public void displays_Enter_valid_enquiry_details() throws Throwable {
        String expectedMessage="Enquiry details must be filled out";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        driver.close();
       
    }


    @Given("^User is on 'Tuition Enquiry Details Form' page$")
    public void user_is_on_Tuition_Enquiry_Details_Form_page() throws Throwable {
        
       
    }


    @When("^User enters valid  Enquiry details$")
    public void user_enters_valid_Enquiry_details() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yarravula");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("9912488866");
        bean.setTypeOfTuition("Spoken English");
        bean.setCity("Pune");
        bean.setModeOfLearning("Class room training");
        bean.setYourEnquiry("Can u mention the tuition timings??");
        bean.setSubmitRequest();
       
    }


    @Then("^displays 'Thank you for submitting the online coaching Class Enquiry'$")
    public void displays_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {
        String expectedMessage="Thank you for submitting the online coaching Class Enquiry";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
    }


    @When("^User clicks 'Submit Your Request' button$")
    public void user_clicks_Submit_Your_Request_button() throws Throwable {
        bean.setFirstName("pavan");
        bean.setLastName("yarravula");
        bean.setEmail("pavan@gmail.com");
        bean.setMobileNo("9912488866");
        bean.setTypeOfTuition("Spoken English");
        bean.setCity("Pune");
        bean.setModeOfLearning("Class room training");
        bean.setYourEnquiry("Can u mention the tuition timings??");
        bean.setSubmitRequest();
       
    }


    @When("^User clicks 'Alert box message'$")
    public void user_clicks_Alert_box_message() throws Throwable {
        driver.switchTo().alert().accept();
        
    }


    @Then("^displays 'Our Counselor will contact you soon'$")
    public void displays_Our_Counselor_will_contact_you_soon() throws Throwable {
        String bodyText=driver.findElement(By.tagName("body")).getText();
        Assert.assertTrue("Text not found!", bodyText.contains("Our Counselor will contact you soon"));
        
    }




}
 