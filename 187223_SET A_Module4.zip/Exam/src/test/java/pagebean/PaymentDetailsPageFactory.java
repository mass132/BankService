package pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPageFactory {
WebDriver driver;

@FindBy(how=How.ID, using="txtCardholderName")
@CacheLookup
WebElement cardholdername;

@FindBy(how=How.ID, using="txtDebit")
@CacheLookup
WebElement debitcardnumber;

@FindBy(how=How.ID, using="txtMonth")
@CacheLookup
WebElement expirymonth;

@FindBy(how=How.ID, using="txtYear")
@CacheLookup
WebElement expiryyear;


@FindBy(how=How.ID, using="txtCvv")
@CacheLookup
WebElement cvv;

@FindBy(how=How.ID, using="btnPayment")
@CacheLookup
WebElement paymentbutton;

//initiating the elements
	public PaymentDetailsPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


public WebElement getCvv() {
		return cvv;
	}


	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}


public WebElement getCardholdername() {
	return cardholdername;
}


public void setCardholdername(String cardholdername) {
	this.cardholdername.sendKeys(cardholdername);
}


public WebElement getDebitcardnumber() {
	return debitcardnumber;
}


public void setDebitcardnumber(String debitcardnumber) {
	this.debitcardnumber.sendKeys(debitcardnumber);
}


public WebElement getExpirymonth() {
	return expirymonth;
}


public void setExpirymonth(String expirymonth) {
	this.expirymonth.sendKeys(expirymonth);
}


public WebElement getExpiryyear() {
	return expiryyear;
}


public void setExpiryyear(String expiryyear) {
	this.expiryyear.sendKeys(expiryyear);
}


public WebElement getPaymentbutton() {
	return paymentbutton;
}


public void setPaymentbutton() {
	this.paymentbutton.click();
}
}
