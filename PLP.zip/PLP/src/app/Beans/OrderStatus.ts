export enum OrderStatus {
	BeingPrepared, Ready, Shipped, Delivered
}