package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Stock;
import com.capgemini.capstore.exceptions.CapStoreException;
import com.capgemini.capstore.service.ICustomerService;
import com.capgemini.capstore.service.IInvoiceService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
	@Autowired
	ICustomerService customerservice;
	
	@Autowired
	IInvoiceService invoiceservice;
	 
	@PostMapping(value="/create")
	public Customer createAccount(@RequestBody Customer customer)
	{
		return customerservice.createAccount(customer);
	}
	
	@GetMapping(value="/getAccount/{customerId}")
	public Customer viewById(@PathVariable long customerId)
	{
		return customerservice.viewById(customerId);
	}
	
	@GetMapping(value="/getCart/{customerId}")
	public List<Cart> getCart(@PathVariable long customerId)

	{
		return invoiceservice.getCart(customerId);
	}
	
	@PutMapping(value="/changePassword/{customerId}/{oldPassword}/{newPassword}")
	public boolean changePassword(@PathVariable long customerId,@PathVariable String oldPassword,@PathVariable String newPassword,@RequestBody Customer customer) throws CapStoreException
	{
		return customerservice.changePassword(customerId,oldPassword,newPassword,customer);
	}
	
	@PostMapping(value="/generateInvoice/{customerId}/{adminDiscount}/{finalAmount}")
	public Invoice generateInvoice(@PathVariable long customerId,@PathVariable double adminDiscount,@PathVariable  double finalAmount )
	{
		return invoiceservice.generateInvoice(customerId,adminDiscount,finalAmount);
	}
	
	@GetMapping(value="/getInvoice/{invoiceId}")
	public Invoice generateInvoice(@PathVariable long invoiceId )
	{
		return invoiceservice.getInvoice(invoiceId);
	}
	
	@PostMapping(value="/generateOrder/{productId}/{invoiceId}")
	public DeliveryStatus generateOrder(@RequestBody Order order,@PathVariable long productId,@PathVariable long invoiceId)
	{
		return invoiceservice.generateOrder(order,productId,invoiceId);
	}
	
	
	
	@GetMapping(value = "/generateCoupon/{couponCode}")
	public Coupon viewByCouponCode(@PathVariable String couponCode) {
		return invoiceservice.viewByCouponCode(couponCode);
	}
	
	@GetMapping(value = "/applyDiscount/{productId}")
	public double viewByProductId(@PathVariable long productId) {
		return invoiceservice.viewByProductId(productId);
	}
	
	@GetMapping(value = "/getPrice/{productId}")
	public double getPrice(@PathVariable long productId) {
		return invoiceservice.getPrice(productId);
	}
	
	@GetMapping(value = "/generateOrders/{customerId}")
	public List<List<Order>> getOrders(@PathVariable long customerId) {
		return invoiceservice.getOrders(customerId);
	}
	
	@PostMapping(value = "/generateCart/{customerId}/{productId}")
	public Cart generateCart(@PathVariable long customerId,@PathVariable long productId) {
		
		return invoiceservice.generateCart(customerId,productId);
	}
	
	@GetMapping(value = "/getOrders/{invoiceId}")
	public List<Order> getOrder(@PathVariable long invoiceId) {
		return invoiceservice.getOrder(invoiceId);
	}
	
	
	@GetMapping("/checkAvailabilityOfProduct/{productId}/{quantity}")
    public boolean findProductQuantity(@PathVariable("productId") long productId,@PathVariable("quantity") Integer quantity){
        boolean result=invoiceservice.findProductQuantity(productId,quantity);
        if(result==false) {
            return false;
        }
        else
        return true;
    }
	
	@PutMapping("/updateInventory/{productId}/{quantity}")
	public Stock updateInventory(@PathVariable Long productId, @PathVariable Integer quantity) {
	    return  invoiceservice.updateInventory(productId, quantity);
	   
	
	}
}
