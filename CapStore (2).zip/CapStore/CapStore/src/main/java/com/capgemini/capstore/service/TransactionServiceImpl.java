package com.capgemini.capstore.service;


import java.util.List;
import java.util.Optional;

import org.hibernate.TransactionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.AccountDetail;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Stock;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.dao.IInvoiceDao;
import com.capgemini.capstore.dao.TransactionDaoI;

@Service
public class TransactionServiceImpl implements TransactionService{
	@Autowired
	TransactionDaoI transactionDao;

	@Autowired
	IInvoiceDao invoiceDao;
	
	 @Autowired
	 ICustomerDao customerDao;
	@Override
	public AccountDetail addAccountDetails(AccountDetail accountDetail,long customerId) throws TransactionException {
		Optional<Customer> optional=customerDao.findById(customerId);
		accountDetail.setCustomer(optional.get());
		try {
			return transactionDao.save(accountDetail);
		} catch (Exception e) {
			throw new TransactionException("Cannot add this account");
		}
	}

	/*public List<AccountDetail> addAccountDetails(long customerId, AccountDetail accountdetail) throws TransactionException{
		try {
		Customer customer=accountdetail.getCustomer().getCustomerId();
		transactionDao.save(customer,accountdetail);
		return transactionDao.findById(customerId);
		}
		catch (Exception e) {
			throw new TransactionException("Cannot add this account");
			
		}
	}*/
	
	
	@Override
	public List<AccountDetail> getAllAccounts() throws TransactionException {

		try {
			return transactionDao.findAll();
		}

		catch (Exception e) {
			throw new TransactionException(e.getMessage() + "(Account not Exists!!!)");
		}
	}
	@Override
	public void deleteAccountById(long cardNo) throws TransactionException {
		try {
			transactionDao.deleteById(cardNo);
		}

		catch (Exception e) {
			throw new TransactionException(
					e.getMessage() + "(Account not exists) Cannot delete this Account: " + cardNo);
		}

	}

	
	@Override
	public AccountDetail updateAccountDetails(long cardNo,double finalAmount)  {
		
		Optional<AccountDetail> optional=transactionDao.findById(cardNo);
		AccountDetail accountDetail=optional.get();
		
		accountDetail.setBalance(accountDetail.getBalance()-finalAmount);
		transactionDao.save(accountDetail);
		return accountDetail;
		
	}

	@Override
	public AccountDetail getTransactionByCustomerId(long customerId) {
		// TODO Auto-generated method stub
		try {
			
			AccountDetail accountDetail=transactionDao.findByCustomer( customerDao.findById(customerId).get());
			return accountDetail;
		} catch (Exception ex) {
			throw new TransactionException(ex.getMessage() + " No account with this CustomerID" + customerId);
		}
	}
	}


	
	


